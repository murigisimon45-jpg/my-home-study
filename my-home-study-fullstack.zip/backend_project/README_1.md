# MY HOME STUDY - Backend

Multi-device backend so teachers and students can register from different phones/computers and data syncs.

## Features
- JWT auth for Student / Teacher
- Teacher ID generation (TCH-XXX) - shareable
- Assignments CRUD
- Submissions with locking (student cannot edit after submit until graded)
- Progress tracking: topic completions, practice scores, concept understanding
- Teacher dashboard endpoint to see all students' progress

## Quick Start

1. Create MongoDB Atlas (free) -> get MONGO_URI
2. Create .env file from .env.example
```
PORT=5000
MONGO_URI=mongodb+srv://...
JWT_SECRET=some_long_secret_12345
CLIENT_URL=http://localhost:5500,https://your-frontend.com
```

3. Install & Run
```bash
npm install
npm run dev   # or npm start
```

API will run at http://localhost:5000

### Deploy options (free):
- Render.com: New Web Service -> connect repo -> build: npm install, start: npm start
- Railway.app: similar
- Set ENV vars in dashboard

## Frontend Integration

In your frontend HTML, set:

```js
const API_BASE = "https://your-backend.onrender.com/api";
```

Replace all LS.get / LS.set calls with fetch:

Example login:
```js
async function doLogin(){
  const res = await fetch(API_BASE+'/auth/login', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({email, password})
  });
  const data = await res.json();
  if(!res.ok) show error
  localStorage.setItem('mhs_token', data.token);
  localStorage.setItem('mhs_user', JSON.stringify(data.user));
}
```

Then include token in all requests:
```js
fetch(API_BASE+'/assignments', {
  headers:{Authorization:'Bearer '+localStorage.getItem('mhs_token')}
})
```

A fully wired frontend file is included: `My-Home-Study_BACKEND.html` - it keeps your exact UI/theme but replaces localStorage with API calls, with offline fallback.

## Data Flow

Teacher registers -> gets TCH-XXX -> shares ID
Student registers with that TCH-XXX -> backend verifies teacher exists
Teacher fetches /progress/teacher/students -> sees every student's completions, practice avg, submissions
Teacher grades via PUT /submissions/:id/grade
Student sees grade notification instantly on any device

## Security
- Passwords hashed with bcryptjs
- JWT expires 30d
- Teacher can only see/delete his own assignments
- Student cannot edit Submitted/Graded submissions